<?php
session_start();
if (!isset($_SESSION["uid"]))
 {
  header("location: login.php");
 }
include('inc/conn.php'); 
	$uid = $_SESSION['uid'];
	$query = "SELECT * FROM user WHERE user_id='$uid'";
	$result = mysqli_query($con, $query);
 	$user_dt=mysqli_fetch_array($result);
?>

<link href="css/bootstrap.min.css" rel="stylesheet">

<title>Welcome - <?php echo $user_dt['user_name']; ?></title>
<a href="admin.php"> Admin Dashboard </a>
<h3> Your Basic Info </h3>
<p> Welcome: <?php echo $user_dt['user_name'];?> </p>
<p> Your Email : <?php echo $user_dt['email'];?> </p>

<hr>

<h4> Other Info </h4>
<?php 
	$uid = $_SESSION['uid'];
	$sql = "SELECT * FROM profile WHERE user_id='$uid'";
	$res = mysqli_query($con, $sql);
	$prof =mysqli_fetch_array($res);
?>

<ul style="list-style: none;">
	<li> Gender: <?php echo $prof['gender'];?> </li>
	<li> DOB: <?php echo $prof['dob'];?> </li>
	<li> Address: <?php echo $prof['address'];?> </li>
	<li> User Pic: <img src="<?php echo $prof['pro_pic'];?>"/></li>
</ul>

