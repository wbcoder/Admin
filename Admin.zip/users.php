<?php
session_start();
if (!isset($_SESSION["uid"]))
 {
  header("location: login.php");
 }
include('inc/conn.php'); 
	$uid = $_SESSION['uid'];
	$query = "SELECT * FROM user WHERE user_id='$uid'";
	$result = mysqli_query($con, $query);
 	$user_dt=mysqli_fetch_array($result);
?>


<title>Welcome - <?php echo $user_dt['user_name']; ?></title>


<p> Welcome: <?php echo $user_dt['user_name'];?> </p>
<p> Your Email : <?php echo $user_dt['email'];?> </p>

<a href="profile.php"> View Profile </a>
<a href="logoff.php"> Log out </a>