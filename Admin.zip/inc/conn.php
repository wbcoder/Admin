<?php
$con=mysqli_connect("localhost","root","");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

// Change database to "test"
$db = mysqli_select_db($con,"admin_db");

if(!$db){
	echo "No Database Found !";
}

?> 