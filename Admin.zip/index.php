<?php include('inc/conn.php'); ?>

<?php 
if(isset($_POST['reg_user'])){
	$username = mysqli_real_escape_string($con, $_POST['us_name']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$pass_wd = md5($password);

	echo "$username"." $email";
	// Perform queries
	 $query = "INSERT INTO user (role_id, user_name, email, password) VALUES ('3','$username','$email','$pass_wd')";
     $result = mysqli_query($con,$query);

     if($result){
     	echo "Record Added !";
     }
     else{
     	echo "Try Again";
     }
}
?>



<form method="POST" action="">

<input type="text" name="us_name" id="us_name" placeholder="User Name">
<br>
<input type="text" name="email" id="email" placeholder="Email">
<br>
<input type="password" name="password" id="password">
<br>
<input type="submit" name="reg_user" id="reg_user" value="Register">


</form>

<a href="login.php"> Login here </a>