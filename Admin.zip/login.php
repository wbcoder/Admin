<?php
session_start();
include('inc/conn.php');

if(isset($_POST['login'])){
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$pass_wd = md5($password);

	$sql = "SELECT * FROM user WHERE email='$email' AND password ='$pass_wd'";
	$result = mysqli_query($con, $sql);
 	$count=mysqli_num_rows($result);

	if ($count == 1) {		
		$row = mysqli_fetch_array($result);
		$_SESSION["uid"] = $row['user_id'];
        $role_id = $row['role_id'];  
        ///echo "$email "."$role_id "."$username";
        if($role_id=="0"){
        	header("location: admin.php");
        }
        else if($role_id=="1"){
        	header("location: cordinator.php");
        }
        else if($role_id=="2"){
        	header("location: staff.php");
        }
        if($role_id=="3"){
        	header("location: users.php");
        }
	}
		else {
		echo "Username or Password Incorrect !";
	}
}

?>


<form method="POST" action="">

<input type="text" name="email" id="email" placeholder="Email">
<br>
<input type="password" name="password" id="password">
<br>
<input type="submit" name="login" id="login" value="Log in">


</form>
